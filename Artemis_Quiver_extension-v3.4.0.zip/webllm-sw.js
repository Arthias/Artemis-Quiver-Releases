import{a2 as e}from"./chunks/vendor-WlnTS6Qo.js";self.addEventListener("activate",()=>{new e,self.clients.claim()});
