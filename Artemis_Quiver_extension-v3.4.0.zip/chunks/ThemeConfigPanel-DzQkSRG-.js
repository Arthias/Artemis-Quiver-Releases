import{ay as u,av as t,C as v,al as w,P as S,aF as h,a5 as N}from"./vendor-WlnTS6Qo.js";import{A as k}from"./errors-DFoKlr1p.js";import{T as E}from"./textarea-hsVvBrR9.js";import{C as g,B as y}from"../app.js";const j=`You MUST return ONLY a valid JSON object. No markdown fences, no text outside the JSON.

Each section in the "sections" array MUST have a "type" field.

EXAMPLE:
{
  "name": "Jane Doe",
  "title": "Senior Software Engineer | Full-Stack Architect",
  "location": "San Francisco, CA",
  "sections": [
    { "type": "summary", "content": "Professional summary text here" },
    { "type": "contact", "email": "user@example.com", "phone": "+1 234 567 890", "linkedin": "https://linkedin.com/in/user", "website": "https://user.com", "location": "San Francisco, CA" },
    { "type": "skills", "skills": ["JavaScript", "Python", "React"], "categories": [{"name": "Languages", "items": ["JavaScript", "Python"]}, {"name": "Frameworks", "items": ["React", "Node.js"]}] },
    { "type": "experience", "experience": [{"role": "Senior Dev", "company": "Acme", "period": "2020-2023", "location": "Remote", "bullets": ["Led a team of 5 engineers, delivering 12 features on schedule", "Reduced deployment time by 40% with CI/CD automation", "Architected microservices serving 2M+ users"]}] },
    { "type": "education", "education": [{"degree": "BSc Computer Science", "institution": "MIT", "period": "2012-2016", "location": "Cambridge, MA"}] },
    { "type": "certifications", "certifications": ["AWS Solutions Architect"] }
  ]
}

TOP-LEVEL FIELDS:
1. "name" — candidate full name (required)
2. "title" — professional headline / role (required)
3. "location" — primary location (optional)

SECTION TYPES:
1. "summary" — object with "content" string
2. "contact" — object with optional email, phone, linkedin, website, location strings
3. "skills" — object with "skills" array OR "categories" array of {name, items[]}
4. "experience" — object with "experience" array of {role, company, period, location?, bullets[]}
5. "education" — object with "education" array of {degree, institution, period, location?}
6. "certifications" — object with "certifications" array of strings

RULES:
- Be FACTUAL — only include information from the profile
- Prefer "bullets" array for experience descriptions (one achievement per bullet) over a single description string
- Categorize skills when possible using the "categories" field
- Return ONLY the JSON object, no text/comments/formatting around it`;function f(e){const a=["You are an expert CV writer and career coach. Generate a professional CV in structured JSON from the candidate profile."];return a.push(`
GENERAL OPTIMIZATION GUIDELINES:
- Summary: Write 2-3 concise sentences that communicate role, years of experience, key strengths, and value proposition. Avoid generic phrases like "results-driven" or "team player" — use specific, substantive claims.
- Experience descriptions: Use strong action verbs (led, drove, designed, implemented, optimized). Prefer measurable achievements over responsibility-listing. Use the pattern: Action + What + Result/Impact.
- Skills: Order by relevance to the target role. Group by category if the list is long.
- Overall: Be concise. Every line should serve a purpose. Cut filler.`),a.push(`
${j}`),a.join(`
`)}function C(e){return`You are an expert CV writer specializing in professional summaries. Rewrite the candidate's summary to be concise, compelling, and aligned with the target role.

Target role: the position
Industry: the relevant field

REQUIREMENTS:
- 2-4 sentences maximum
- Lead with years of experience and role title
- Include 1-2 key differentiators (notable achievements, unique skills, or impact metrics)
- Match the tone and language of the target industry
- Avoid clichés: "results-driven", "team player", "go-getter", "hardworking"
- End with what the candidate offers the employer, not what they seek

Return ONLY the rewritten summary text — no JSON, no commentary.`}function I(e){return`You are an expert CV writer specializing in achievement-oriented bullet points. Rewrite the provided experience descriptions to focus on measurable accomplishments.

REQUIREMENTS:
- Start each bullet with a strong action verb (led, designed, increased, reduced, negotiated, launched, optimized)
- Follow the format: Action + What You Did + Measurable Result
- Add numbers, percentages, dollar amounts, or timeframes wherever the profile supports them
- Eliminate passive voice and generic responsibility statements
- Examples of what to avoid:
  "Was responsible for managing a team" → "Led a team of 8 engineers, delivering 12 projects on time"
  "Helped with customer onboarding" → "Designed onboarding workflow that reduced time-to-value by 40%"
- If the profile doesn't include specific numbers, infer plausible metrics from context (team size, project scope, impact)

Return ONLY the rewritten bullet points as a bullet list — no JSON, no commentary.`}function T(e){return`You are an ATS (Applicant Tracking System) optimization expert. Rewrite the CV content so it ranks well with automated screeners while remaining natural and readable to human reviewers.

Job description provided below. Use it to identify:
1. Required skills, tools, and certifications — ensure these appear verbatim where the profile supports them
2. Preferred qualifications — weave these in naturally where applicable
3. Industry terminology and keywords from the posting
4. Action verbs and phrasing patterns used in the job description

ATS GUIDELINES:
- Use the exact keyword phrasing from the job description (not synonyms) where the profile supports it
- Place critical keywords in context (within experience descriptions and skills, not forced into a keyword dump)
- Avoid tables, columns, or special characters that confuse parsers
- Use standard section headings (Summary, Experience, Education, Skills)
- Spell out acronyms on first use, then use the acronym
- Do NOT fabricate skills or experience that aren't in the profile
- Keep the language natural — keyword stuffing is detectable by modern ATS

Return the full CV content optimized for ATS.`}function A(e){return`You are a career transition coach. Help reframe the candidate's experience from your previous field to position them strongly for your new target field.

STRATEGIES:
- Identify transferable skills: project management, communication, analysis, leadership, client management, technical aptitudes that cross domains
- Recontextualize past achievements: describe past accomplishments using language that resonates in the new field
- Lead with a narrative: the summary should tell a coherent story about why this career move makes sense and brings unique value
- Don't hide the transition — frame it as a strategic move that brings a differentiated perspective
- If there's a gap between fields, suggest bridge experiences (volunteer work, courses, projects, certifications)

Return the reframed CV content highlighting transferable skills and career change narrative. Stay factual — do not invent experience in the new field.`}function R(e){return`You are a senior hiring manager and resume reviewer with 15+ years of experience across multiple industries. Audit the candidate's CV and provide frank, specific feedback.

AUDIT CRITERIA:
1. VAGUENESS: Flag any description that lacks specifics (team size, scope, technologies, outcomes)
2. WORDINESS: Cut redundant phrases, filler adjectives, and unnecessarily long sentences
3. IMPACT: Identify bullets that state responsibilities but don't communicate results
4. LEADERSHIP: Note where leadership, initiative, or ownership could be better highlighted
5. INNOVATION: Identify areas where the candidate solved problems or improved things that read as routine
6. STRUCTURE: Assess section ordering, readability, whether the most important content is prominent
7. TONE: Evaluate whether the voice is confident vs. passive, active vs. descriptive
8. GAPS: Point out any missing context (dates, technologies, scope) that a hiring manager would wonder about

For each issue found, provide:
- Location (which section)
- The problem (what's weak)
- A suggested rewrite (how to fix it)

Return the audit in a structured format. Be direct — the candidate wants honest feedback, not encouragement.`}function O(e){return`You are a career alignment specialist. Restructure the candidate's work history to maximize relevance to the target role.

ALIGNMENT GUIDELINES:
- For each past role, identify 1-3 accomplishments that most directly map to the target job's required qualifications
- Reorder bullet points within each role so the most relevant achievements appear first
- Where the candidate's language differs from the job description, suggest phrasing that matches the target role's terminology
- If the role seems unrelated, find and emphasize the transferable elements (budget management, team leadership, client work, process improvement)
- Consider whether the roles are best presented chronologically or in a "relevant experience" / "additional experience" structure

Return the restructured work history with explanations of why each change improves alignment.`}function P(e){return`You are a technical resume specialist. Build or optimize the candidate's skills section.

GUIDELINES:
- Categorize skills (Languages, Frameworks, Tools, Platforms, Soft Skills) for scannability
- Order each category by relevance to the target role, not alphabetically
- Include proficiency indicators only if the candidate has a clear tier (Expert, Proficient, Familiar) — do not invent ratings
- Suggest 1-2 skills the candidate might reasonably claim based on their experience (even if not explicitly listed in the profile)
- Flag any skills in the profile that are outdated or irrelevant to the target role
- Keep the section compact — 15-25 well-chosen skills is more effective than 50+ scattered ones

Return the optimized skills section as a categorized list.`}function F(e){return`You are a personal branding specialist. Write a powerful resume headline and subheadline.

FORMAT:
- Headline: 5-10 word phrase that communicates role, seniority, and primary differentiator
- Subheadline: 1-2 sentence expansion on value proposition

EXAMPLES:
"Senior Product Manager | SaaS Growth & Platform Strategy"
"Led 3× revenue growth across $50M product portfolio through data-driven roadmap prioritization and cross-functional execution"

"Full-Stack Engineer | React, Node.js, AWS"
"Built scalable platforms serving 2M+ users, reducing infrastructure costs 35% through cloud architecture redesign"

REQUIREMENTS:
- The headline should immediately tell the reader who you are and what you offer
- The subheadline should include 1 measurable achievement or scope indicator
- Use industry-appropriate keywords
- Avoid generic labels ("Professional", "Experienced", "Results-Oriented")

Return only the headline and subheadline — no JSON, no commentary.`}function L(e){return`You are a hiring manager at a leading company looking to fill a senior-level role. You review 200+ resumes for every open position. Be direct, critical, and specific about what would make you shortlist or reject this candidate.

ANSWER THESE QUESTIONS IN YOUR FEEDBACK:
1. Would you invite this candidate for an interview? Why or why not?
2. What is the first thing that makes you hesitate?
3. What specific changes would increase your confidence in this candidate?
4. What's missing that you'd expect to see for this level of role?
5. Is there anything on this resume that raises a red flag?
6. If you interviewed this person, what are the top 3 things you'd want to verify or probe deeper?

Be specific. Reference particular lines or sections of the resume. Don't just say "add more metrics" — point to where and what kind. The candidate wants actionable, honest feedback from the person who actually makes hiring decisions.`}function $(e){return`You are an expert CV editor. Apply the user's requested changes to the CV JSON below.

General quality standards for all edits:
- Experience descriptions should use strong action verbs and measurable outcomes
- Summary should be concise and value-focused
- Skills should be relevant and well-organized
- Avoid vague or generic language throughout

User request: ${e}

Return ONLY the revised JSON object — no markdown wrappers, no text, no commentary. Each section MUST have a "type" field.`}function q(e,a,i){switch(e){case"standard":return f();case"summary-rewrite":return C();case"bullet-optimize":return I();case"ats-optimize":return T();case"career-transition":return A();case"audit":return R();case"work-history-align":return O();case"skills-section":return P();case"headline":return F();case"hiring-manager":return L();default:return f()}}const x=`You MUST return ONLY a valid JSON object. No markdown fences, no text outside the JSON.

EXAMPLE:
{
  "senderName": "Jane Doe",
  "senderTitle": "Senior Software Engineer",
  "date": "May 29, 2026",
  "recipientName": "Hiring Manager",
  "companyName": "Acme Corp",
  "companyLocation": "San Francisco, CA",
  "position": "Senior Engineer",
  "subject": "Application for Senior Engineer Position",
  "salutation": "Dear Hiring Manager,",
  "bodyParagraphs": [
    "I am writing to express my strong interest in the Senior Engineer position at Acme Corp. With 8 years of experience in full-stack development, I have honed skills in React, Node.js, and cloud architecture that align closely with the requirements of this role.",
    "In my current role at TechCo, I led a team of 5 engineers delivering 12 major features on schedule. I reduced deployment time by 40% through CI/CD automation and architected microservices serving 2M+ users.",
    "I would welcome the opportunity to discuss how my technical leadership and product instincts can drive impact at Acme Corp."
  ],
  "closing": "Sincerely,"
}

TOP-LEVEL FIELDS:
1. "senderName" — your full name (required)
2. "senderTitle" — your professional title (optional)
3. "date" — letter date string (optional)
4. "recipientName" — hiring manager name if known (optional, default "Hiring Manager")
5. "companyName" — target company (optional)
6. "companyLocation" — company city, state (optional)
7. "position" — target position title (optional)
8. "subject" — Re: subject line (optional)
9. "salutation" — greeting line (required, e.g. "Dear Hiring Manager,")
10. "bodyParagraphs" — array of paragraph strings (required, at least 1)
11. "closing" — sign-off (required, e.g. "Sincerely,")

RULES:
- Be FACTUAL — only include information from the candidate profile
- Write 3-4 paragraphs: opening (role interest + fit), middle (key achievements), closing (enthusiasm + call to action)
- Use professional business letter tone
- Return ONLY the JSON object, no text/comments/formatting around it`;function J(e,a,i){const r=["You are an expert cover letter writer and career coach."];return i&&r.push("The candidate has provided a job description below. Tailor the cover letter to that specific role, mirroring key requirements and showing how the candidate's experience addresses them."),r.push(`
WRITING GUIDELINES:
- Opening paragraph: State the role you're applying for, express enthusiasm, and give a 1-sentence overview of why you're a strong fit.
- Middle paragraphs (1-2): Highlight 2-3 specific achievements or experiences from the profile that directly map to job requirements. Use metrics where possible.
- Closing paragraph: Reiterate enthusiasm, mention desire for an interview, and thank the reader.
- Tone: Professional, confident, specific. Avoid clichés like "I am writing to apply" (instead, lead with enthusiasm and fit).
- If no job description is provided, write a general but compelling letter highlighting the candidate's strongest attributes.

${x}`),r.join(`
`)}function G(e){return`You are a cover letter editor. Apply the user's requested changes to the cover letter JSON below.

User request: "${e}"

RULES:
- Preserve all fields unless the user explicitly asks to change them
- Modify only the bodyParagraphs unless otherwise requested
- Keep the same tone unless asked to change it
- Return ONLY valid JSON, no text outside

${x}`}function W({value:e,onSave:a,className:i,placeholder:r,style:n}){const[s,c]=u.useState(!1),[l,o]=u.useState(e);return s?t.jsx("input",{value:l,onChange:d=>o(d.target.value),onBlur:()=>{a(l||e),c(!1)},onKeyDown:d=>{d.key==="Enter"&&(a(l||e),c(!1)),d.key==="Escape"&&(o(e),c(!1))},autoFocus:!0,className:`bg-white text-gray-900 border border-gray-300 rounded px-1.5 py-0.5 focus:outline-none focus:ring-2 focus:ring-blue-400 ${i??""}`,placeholder:r,style:n}):t.jsx("span",{onClick:()=>c(!0),className:`cursor-pointer rounded px-1 -mx-1 hover:bg-gray-100 transition-colors ${i??""}`,title:"Click to edit",style:n,children:e})}function B({value:e,onSave:a,className:i}){const[r,n]=u.useState(!1),[s,c]=u.useState(e);return r?t.jsxs("div",{className:"space-y-2",children:[t.jsx("textarea",{value:s,onChange:l=>c(l.target.value),className:`w-full bg-white text-gray-900 border border-gray-300 rounded-md p-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-400 ${i??""}`,rows:4,autoFocus:!0}),t.jsxs("div",{className:"flex gap-2",children:[t.jsxs("button",{onClick:()=>{a(s),n(!1)},className:"inline-flex items-center gap-1 px-3 py-1 bg-blue-600 text-white text-xs rounded hover:bg-blue-700",children:[t.jsx(v,{className:"w-3 h-3"})," Save"]}),t.jsxs("button",{onClick:()=>{c(e),n(!1)},className:"inline-flex items-center gap-1 px-3 py-1 bg-gray-200 text-gray-700 text-xs rounded hover:bg-gray-300",children:[t.jsx(w,{className:"w-3 h-3"})," Cancel"]})]})]}):t.jsxs("div",{onClick:()=>n(!0),className:"cursor-pointer group relative rounded-md p-2 -m-2 hover:bg-gray-50 transition-colors",children:[t.jsx("p",{className:"text-gray-700 leading-relaxed whitespace-pre-wrap",children:e}),t.jsx("span",{className:"absolute top-1 right-1 opacity-0 group-hover:opacity-100 text-gray-400",children:t.jsx(S,{className:"w-3.5 h-3.5"})})]})}function p(e,a){return/^#[0-9A-Fa-f]{6}$/.test(e)?e:a}function V(e){const a=p(e.primaryColor,"#1e293b"),i=p(e.accentColor,"#2563eb"),r=p(e.textColor,"#475569"),n=e.headingFont||"'Inter', -apple-system, sans-serif",s=e.bodyFont||"'Inter', -apple-system, sans-serif";return{fontFamily:s,headingFont:n,name:{fontSize:"2rem",fontWeight:800,color:a,letterSpacing:"-0.025em",fontFamily:n},title:{fontSize:"1.05rem",color:i,fontWeight:600,fontFamily:n},sectionTitle:{fontSize:"0.7rem",fontWeight:700,textTransform:"uppercase",letterSpacing:"0.1em",color:i,fontFamily:n},body:{fontSize:"0.85rem",color:r,lineHeight:1.6,fontFamily:s},muted:{fontSize:"0.8rem",color:"#64748b",fontFamily:s},card:{background:"#fff",boxShadow:"0 1px 3px rgba(0,0,0,0.1)",borderRadius:"8px"},tag:{background:`${i}15`,color:"#334155",borderRadius:"3px",fontFamily:s},contactIcon:{color:"#94a3b8"},divider:{borderTop:"2px solid #e2e8f0",margin:"1rem 0"},container:{background:"#f8fafc"},editInput:{},editOverlay:"bg-blue-50/30"}}const m="[AppError]";function _(e,a){var i,r;if(e instanceof k){const n={...e.toJSON(),context:a??{},stack:(i=e.stack)==null?void 0:i.split(`
`).slice(0,4).join(`
`)};console.group(`${m} ${e.code}`),console.error("detail",n),e.metadata&&Object.keys(e.metadata).length>0&&console.error("metadata",e.metadata),console.groupEnd();return}if(e instanceof Error){console.error(`${m} [Uncategorized] ${e.message}`,{name:e.name,message:e.message,stack:(r=e.stack)==null?void 0:r.split(`
`).slice(0,4).join(`
`),context:a});return}console.error(`${m} [Unknown]`,{value:String(e),context:a})}function H({suggestions:e,chatMessage:a,chatLoading:i,onChatMessageChange:r,onSubmit:n,accentClass:s="text-purple-500",panelBg:c="bg-muted/30"}){const{t:l}=h();return t.jsxs("div",{className:`w-96 flex flex-col ${c} border-l border-border`,children:[t.jsxs("div",{className:"p-4 border-b border-border",children:[t.jsxs("div",{className:"flex items-center gap-2",children:[t.jsx(N,{className:`w-5 h-5 ${s}`}),t.jsx("h3",{className:"font-semibold",children:l("builder.aiAssistant")})]}),t.jsx("p",{className:"text-xs text-muted-foreground mt-1",children:l("builder.assistantDesc")})]}),t.jsx("div",{className:"flex-1 overflow-auto p-4 space-y-3",children:e.map(o=>t.jsxs(g,{className:"p-3 bg-card hover:bg-accent/50 cursor-pointer transition-colors",onClick:()=>n(o.prompt),children:[t.jsx("p",{className:"text-sm font-medium",children:o.title}),t.jsx("p",{className:"text-xs text-muted-foreground",children:o.hint})]},o.title))}),t.jsxs("div",{className:"p-4 border-t border-border",children:[t.jsx(E,{value:a,onChange:o=>r(o.target.value),onKeyDown:o=>{o.key==="Enter"&&!o.shiftKey&&(o.preventDefault(),n())},placeholder:l("builder.chatPlaceholder"),className:"resize-none bg-input-background border-border text-sm",rows:3,disabled:i}),t.jsx(y,{onClick:()=>n(),disabled:!a.trim()||i,className:"w-full mt-2",size:"sm",children:l(i?"builder.applying":"builder.applyChanges")})]})]})}function K({error:e,retryableError:a,onRetry:i}){const{t:r}=h();return e?t.jsx(g,{className:"p-3 mb-4 text-sm border-destructive/50 bg-destructive/5",children:t.jsxs("div",{className:"flex items-start gap-2",children:[t.jsx("pre",{className:"whitespace-pre-wrap font-sans text-destructive flex-1",children:e}),a&&t.jsx(y,{size:"sm",variant:"outline",className:"flex-shrink-0 border-destructive/30 text-destructive hover:bg-destructive/10",onClick:i,children:r("builder.retry")})]})}):null}const b=[{value:"'Inter', -apple-system, sans-serif",label:"Inter (Sans)"},{value:"'Georgia', 'Times New Roman', serif",label:"Georgia (Serif)"},{value:"'Playfair Display', Georgia, serif",label:"Playfair Display"},{value:"'Roboto', -apple-system, sans-serif",label:"Roboto (Sans)"},{value:"'Open Sans', -apple-system, sans-serif",label:"Open Sans"},{value:"'Times New Roman', Times, serif",label:"Times New Roman (Serif)"},{value:"'Courier New', monospace",label:"Courier New (Mono)"}],U=[{value:"classic",labelKey:"builder.templateClassic"},{value:"executive",labelKey:"builder.templateExecutive"}];function X({config:e,onChange:a}){const{t:i}=h();return t.jsxs(g,{className:"p-3 mt-3 bg-muted/50 border-dashed",children:[t.jsx("div",{className:"text-sm font-medium mb-2",children:i("builder.themeConfig")}),t.jsxs("div",{className:"flex flex-wrap items-start gap-4",children:[t.jsxs("div",{children:[t.jsx("label",{className:"block text-xs text-muted-foreground mb-1",children:i("builder.template")}),t.jsx("div",{className:"flex gap-1",children:U.map(r=>t.jsx("button",{onClick:()=>a({...e,templateId:r.value}),className:`text-xs px-3 py-1.5 rounded-md border transition-colors ${e.templateId===r.value?"bg-foreground text-background border-foreground":"bg-background text-foreground border-border hover:bg-muted"}`,children:i(r.labelKey)},r.value))})]}),t.jsxs("div",{children:[t.jsx("label",{className:"block text-xs text-muted-foreground mb-1",children:i("builder.primaryColor")}),t.jsx("input",{type:"color",value:e.primaryColor,onChange:r=>a({...e,primaryColor:r.target.value}),className:"w-8 h-8 border rounded cursor-pointer p-0"})]}),t.jsxs("div",{children:[t.jsx("label",{className:"block text-xs text-muted-foreground mb-1",children:i("builder.accentColor")}),t.jsx("input",{type:"color",value:e.accentColor,onChange:r=>a({...e,accentColor:r.target.value}),className:"w-8 h-8 border rounded cursor-pointer p-0"})]}),t.jsxs("div",{children:[t.jsx("label",{className:"block text-xs text-muted-foreground mb-1",children:i("builder.textColor")}),t.jsx("input",{type:"color",value:e.textColor,onChange:r=>a({...e,textColor:r.target.value}),className:"w-8 h-8 border rounded cursor-pointer p-0"})]}),t.jsxs("div",{children:[t.jsx("label",{className:"block text-xs text-muted-foreground mb-1",children:i("builder.headingFont")}),t.jsx("select",{value:e.headingFont,onChange:r=>a({...e,headingFont:r.target.value}),className:"text-sm border rounded px-2 py-1 bg-background text-foreground max-w-[180px]",children:b.map(r=>t.jsx("option",{value:r.value,children:r.label},r.value))})]}),t.jsxs("div",{children:[t.jsx("label",{className:"block text-xs text-muted-foreground mb-1",children:i("builder.bodyFont")}),t.jsx("select",{value:e.bodyFont,onChange:r=>a({...e,bodyFont:r.target.value}),className:"text-sm border rounded px-2 py-1 bg-background text-foreground max-w-[180px]",children:b.map(r=>t.jsx("option",{value:r.value,children:r.label},r.value))})]})]})]})}export{H as B,W as I,X as T,K as a,B as b,G as c,J as d,$ as e,V as g,_ as l,q as s};
