const B={"overlay.matchScore":"Match Score","overlay.scoreFailed":"Score Failed","overlay.analyzing":"Analyzing...","overlay.notConfigured":"Not Configured","overlay.jobPosting":"Job posting","overlay.clickToExpand":"Click to expand","overlay.close":"Close","overlay.noFingerprint":"No profile fingerprint.","overlay.noFingerprintDesc":"Open the Artemis Quiver popup and generate a fingerprint to get AI match scores.","overlay.scoringFailed":"Match scoring failed.","overlay.nanUnavailable":"Gemini Nano is unavailable. Switch the fallback mode in the extension popup to enable AI scoring.","overlay.checkEndpoint":"Check that your LLM endpoint is configured in settings and the server is running.","overlay.retry":"Retry","overlay.analyzingMatch":"Analyzing job match…","overlay.breakdown":"Breakdown","overlay.skills":"Skills","overlay.exp":"Exp.","overlay.company":"Company:","overlay.salary":"Salary:","overlay.importing":"Importing...","overlay.importToArtemis":"Import to Artemis","overlay.openInArtemis":"Open in Artemis →","overlay.imported":"✓ Imported","overlay.testing":"Testing...","overlay.testChromeAI":"Test Chrome AI","overlay.bridgeNotLoaded":"✗ Bridge not loaded","overlay.nanoAvailable":"✓ Available","overlay.nanoErrorTimedOut":"✗ Error (timed out)"};function i(e){return B[e]||e}const j="artemis:overlayConfig",L="artemis:overlayPosition";function J(e){let t=e.trim().toLowerCase();t=t.replace(/^https?:\/\//,""),t=t.replace(/\/+$/,"");const o=t.indexOf("/");return o===-1?{domain:t}:{domain:t.slice(0,o),pathPattern:t.slice(o)}}function q(e,t){return t===e||t.endsWith("."+e)}function D(e,t){let o,a;try{const n=new URL(e);o=n.hostname,a=n.pathname}catch{return!1}for(const n of t){const r=J(n);if(q(r.domain,o)){if(r.pathPattern){const l=r.pathPattern.endsWith("*")?r.pathPattern.slice(0,-1):r.pathPattern;if(!a.startsWith(l))continue}return!0}}return!1}async function U(){try{return(await chrome.storage.local.get(j))[j]||{enabled:!0,jobSites:[],fallbackMode:"basic"}}catch(e){return console.error("[Artemis] Failed to load config:",e),{enabled:!0,jobSites:[],fallbackMode:"basic"}}}async function W(){try{return(await chrome.storage.local.get(L))[L]||{x:20,y:20}}catch(e){return console.error("[Artemis] Failed to load position:",e),{x:20,y:20}}}async function Y(e){await chrome.storage.local.set({[L]:e})}const X=`
  #artemis-overlay {
    all: initial;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    position: fixed; z-index: 2147483647;
    cursor: grab; user-select: none;
    border-radius: 12px; background: #1e293b; color: #f1f5f9;
    box-shadow: 0 8px 32px rgba(0,0,0,0.3);
    font-size: 14px; line-height: 1.4;
    min-width: 160px; max-width: 360px;
    transition: box-shadow 0.2s;
  }
  #artemis-overlay:hover { box-shadow: 0 12px 40px rgba(0,0,0,0.4); }
  #artemis-overlay * { box-sizing: border-box; margin: 0; padding: 0; }
  #artemis-overlay .ao-header {
    display: flex; align-items: center; gap: 8px;
    padding: 10px 12px; cursor: grab;
    border-bottom: 1px solid rgba(255,255,255,0.08);
  }
  #artemis-overlay .ao-header:active { cursor: grabbing; }
  #artemis-overlay .ao-header-info { flex: 1; min-width: 0; }
  #artemis-overlay .ao-header-info .ao-label { font-size: 11px; color: #94a3b8; text-transform: uppercase; letter-spacing: 0.5px; }
  #artemis-overlay .ao-header-info .ao-value { font-weight: 600; font-size: 14px; }
  #artemis-overlay .ao-close {
    width: 24px; height: 24px; border: none; background: rgba(255,255,255,0.1);
    border-radius: 6px; color: #94a3b8; cursor: pointer; font-size: 14px;
    display: flex; align-items: center; justify-content: center; flex-shrink: 0;
  }
  #artemis-overlay .ao-close:hover { background: rgba(255,255,255,0.2); color: #fff; }
  #artemis-overlay .ao-body { padding: 0 12px 12px; display: none; }
  #artemis-overlay.ao-expanded .ao-body { display: block; }
  #artemis-overlay.ao-expanded { min-width: 320px; }
  #artemis-overlay .ao-body-section { margin-top: 10px; }
  #artemis-overlay .ao-body-section h4 { font-size: 11px; color: #94a3b8; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 4px; }
  #artemis-overlay .ao-breakdown-row { display: flex; align-items: center; gap: 8px; margin-top: 4px; font-size: 13px; }
  #artemis-overlay .ao-breakdown-row .ao-bar { flex: 1; height: 6px; background: rgba(255,255,255,0.1); border-radius: 3px; overflow: hidden; }
  #artemis-overlay .ao-breakdown-row .ao-bar-fill { height: 100%; border-radius: 3px; transition: width 0.5s; }
  #artemis-overlay .ao-import-btn {
    display: block; width: 100%; margin-top: 10px;
    padding: 8px 16px; border: none; border-radius: 8px;
    background: #3b82f6; color: #fff; font-size: 13px; font-weight: 600;
    cursor: pointer; transition: background 0.2s;
  }
  #artemis-overlay .ao-import-btn:hover { background: #2563eb; }
  #artemis-overlay .ao-extract-item { font-size: 13px; margin-top: 2px; color: #e2e8f0; }
  #artemis-overlay .ao-extract-item strong { color: #94a3b8; font-weight: 500; }
  #artemis-overlay .ao-summary-text { font-size: 13px; color: #cbd5e1; margin-top: 4px; line-height: 1.5; }
  #artemis-overlay .ao-action-row { display: flex; gap: 6px; margin-top: 10px; }
  #artemis-overlay .ao-sec-btn {
    flex: 1; padding: 8px; border: 1px solid rgba(255,255,255,0.15); border-radius: 8px;
    background: transparent; color: #e2e8f0; font-size: 12px; font-weight: 500;
    cursor: pointer; transition: all 0.2s; text-align: center;
  }
  #artemis-overlay .ao-sec-btn:hover { background: rgba(255,255,255,0.08); border-color: rgba(255,255,255,0.25); }
  #artemis-overlay .ao-info-box {
    padding: 10px; border-radius: 8px;
    border: 1px solid rgba(148,163,184,0.2);
    background: rgba(148,163,184,0.08);
    font-size: 13px; color: #94a3b8; line-height: 1.5;
  }
  #artemis-overlay .ao-expand-hint { color: #64748b; font-size: 10px; flex-shrink: 0; }
  #artemis-overlay.ao-expanded .ao-expand-hint { display: none; }
  /* Circular ring indicator */
  #artemis-overlay .ao-ring-wrap { width:44px;height:44px;flex-shrink:0;position:relative;display:flex;align-items:center;justify-content:center }
  #artemis-overlay .ao-ring-wrap svg { display:block }
  #artemis-overlay .ao-spinner { animation:ao-spin 1s linear infinite }
  @keyframes ao-spin { to { transform:rotate(360deg) } }
  #artemis-overlay .ao-bullseye { position:absolute;inset:0;display:flex;align-items:center;justify-content:center;pointer-events:none }
  #artemis-overlay .ao-bullseye::after { content:'';display:block;width:44px;height:44px;border-radius:50%;background:rgba(234,179,8,0.3);animation:ao-pulse 1s ease-out infinite;transform-origin:center }
  @keyframes ao-pulse { 0% { transform:scale(0.15);opacity:.6 } 100% { transform:scale(1);opacity:0 } }
`;function G(e,t,o,a){try{chrome.runtime.sendMessage({type:"ARTEMIS_LOG_ERROR",payload:{message:e,stack:t,source:"overlay",timestamp:new Date().toISOString(),code:o,metadata:a}}).catch(()=>{})}catch{}}const H=console.error.bind(console);console.error=(...e)=>{var a;H(...e);const t=e.map(n=>typeof n=="object"?n instanceof Error?n.message:JSON.stringify(n):String(n)).join(" "),o=(a=e.find(n=>n instanceof Error))==null?void 0:a.stack;G(t,o)};let k=null,w=!1,g=!1,d=null,h=!1,M=!1,A=!1,x={title:"",company:"",salary:""},f=null,E=!1,C="basic",_=!1;function $(e){const t=document.createElement("div");return t.textContent=e,t.innerHTML}function N(e){var l,c,u;let t="",o="",a="";const n=document.querySelector(".jobs-unified-top-card__title");if(n){t=((l=n.innerText)==null?void 0:l.trim())||"";const s=document.querySelector(".jobs-unified-top-card__company-name");s&&(o=((c=s.innerText)==null?void 0:c.trim())||"")}else{const s=document.querySelector("h1");s&&(t=((u=s.innerText)==null?void 0:u.trim())||"")}t||(t=document.title);const r=e.match(/(\$\d[\d,]*\s*(?:-\s*\$?\d[\d,]*)?\s*(?:\/yr|\/year|per year|k)?)/i);return r&&(a=r[1].trim()),{title:t,company:o,salary:a}}function K(){return i(d!==null?"overlay.matchScore":h?"overlay.scoreFailed":g?"overlay.analyzing":"overlay.notConfigured")}function V(){const t=2*Math.PI*18;if(h)return'<div class="ao-ring-wrap"><svg viewBox="0 0 44 44" width="44" height="44"><circle cx="22" cy="22" r="18" fill="none" stroke="#dc2626" stroke-width="4" opacity=".5"/><text x="22" y="22" text-anchor="middle" dominant-baseline="central" fill="#dc2626" font-size="16" font-weight="700">!</text></svg></div>';if(!g)return'<div class="ao-ring-wrap"><svg viewBox="0 0 44 44" width="44" height="44"><circle cx="22" cy="22" r="18" fill="none" stroke="#475569" stroke-width="4"/><text x="22" y="22" text-anchor="middle" dominant-baseline="central" fill="#94a3b8" font-size="16" font-weight="700">?</text></svg></div>';if(d===null)return'<div class="ao-ring-wrap"><svg viewBox="0 0 44 44" width="44" height="44" class="ao-spinner"><circle cx="22" cy="22" r="18" fill="none" stroke="#334155" stroke-width="4"/><circle cx="22" cy="22" r="18" fill="none" stroke="#eab308" stroke-width="4" stroke-dasharray="50 63" stroke-linecap="round"/></svg><div class="ao-bullseye"></div></div>';const o=d>=70?"#059669":d>=40?"#d97706":"#dc2626",a=t*(1-d/100);return`<div class="ao-ring-wrap"><svg viewBox="0 0 44 44" width="44" height="44"><circle cx="22" cy="22" r="18" fill="none" stroke="#334155" stroke-width="4"/><circle cx="22" cy="22" r="18" fill="none" stroke="${o}" stroke-width="4" stroke-dasharray="${t}" stroke-dashoffset="${a}" stroke-linecap="round" transform="rotate(-90 22 22)" style="transition:stroke-dashoffset 1s ease"/><text x="22" y="22" text-anchor="middle" dominant-baseline="central" fill="#f1f5f9" font-size="14" font-weight="700">${d}%</text></svg></div>`}function m(){const e=k;e&&(e.className=w?"ao-expanded":"",e.innerHTML=`
    <div class="ao-header" data-drag>
      ${V()}
      <div class="ao-header-info">
        <div class="ao-label">${K()}</div>
        <div class="ao-value">${$(x.title||i(w?"overlay.jobPosting":"overlay.clickToExpand"))}</div>
      </div>
      <button class="ao-close" data-action="close" title="${i("overlay.close")}">✕</button>
      <span class="ao-expand-hint">${w?"▲":"▼"}</span>
    </div>
    ${w?`
      <div class="ao-body">
        ${g?h?`
        <div class="ao-body-section">
          <div class="ao-info-box" style="border-color:rgba(239,68,68,0.3);background:rgba(239,68,68,0.08);color:#ef4444">
            <strong>${i("overlay.scoringFailed")}</strong> ${i(C==="basic"?"overlay.nanUnavailable":"overlay.checkEndpoint")}
            <br><button class="ao-sec-btn" data-action="retry" style="margin-top:8px;width:auto;display:inline-block;padding:4px 12px;font-size:12px">${i("overlay.retry")}</button>
          </div>
        </div>
        `:d===null?`
        <div class="ao-body-section">
          <div class="ao-info-box" style="border-color:rgba(234,179,8,0.3);background:rgba(234,179,8,0.08);color:#eab308">
            ${i("overlay.analyzingMatch")}
          </div>
        </div>
        `:`
        <div class="ao-body-section">
          <h4>${i("overlay.breakdown")}</h4>
          <div class="ao-breakdown-row">
            <span style="width:60px">${i("overlay.skills")}</span>
            <div class="ao-bar"><div class="ao-bar-fill" style="width:${Math.min(d+10,100)}%;background:#3b82f6"></div></div>
          </div>
          <div class="ao-breakdown-row">
            <span style="width:60px">${i("overlay.exp")}</span>
            <div class="ao-bar"><div class="ao-bar-fill" style="width:${Math.min(d,100)}%;background:#8b5cf6"></div></div>
          </div>
        </div>
        `:`
        <div class="ao-body-section">
          <div class="ao-info-box">
            <strong>${i("overlay.noFingerprint")}</strong><br>
            ${i("overlay.noFingerprintDesc")}
          </div>
        </div>
        `}
        ${x.company?`<div class="ao-extract-item"><strong>${i("overlay.company")}</strong> ${$(x.company)}</div>`:""}
        ${x.salary?`<div class="ao-extract-item"><strong>${i("overlay.salary")}</strong> ${$(x.salary)}</div>`:""}
        <div class="ao-action-row">
          ${A?"":`<button class="ao-sec-btn" data-action="import">${i(M?"overlay.importing":"overlay.importToArtemis")}</button>`}
          ${A?`<button class="ao-sec-btn" data-action="open-app">${i("overlay.openInArtemis")}</button>`:""}
        </div>
        ${A?`<div style="text-align:center;margin-top:6px;font-size:12px;color:#059669">${i("overlay.imported")}</div>`:""}
        <div class="ao-body-section">
          <div style="border-top:1px solid rgba(255,255,255,0.06);padding-top:8px;margin-top:4px">
            ${f!==null?`<div style="font-size:11px;color:#94a3b8;margin-bottom:4px">${$(f)}</div>`:""}
            <button class="ao-sec-btn" data-action="test-nano" style="width:auto;display:inline-block;padding:3px 10px;font-size:11px">${i(E?"overlay.testing":"overlay.testChromeAI")}</button>
          </div>
        </div>
      </div>
    `:""}
  `)}function Q(e){let t=!1;e.addEventListener("mousedown",o=>{if(!o.target.closest("[data-drag]")||o.target.closest("button"))return;let n=!1;const r=o.clientX,l=o.clientY,c=parseInt(e.style.left)||0,u=parseInt(e.style.top)||0,s=y=>{const v=y.clientX-r,T=y.clientY-l;(Math.abs(v)>3||Math.abs(T)>3)&&(n=!0),e.style.left=c+v+"px",e.style.top=u+T+"px"},p=()=>{document.removeEventListener("mousemove",s),document.removeEventListener("mouseup",p),n&&(t=!0,Y({x:parseInt(e.style.left)||0,y:parseInt(e.style.top)||0}))};document.addEventListener("mousemove",s),document.addEventListener("mouseup",p)}),e.addEventListener("click",o=>{const a=t;t=!1;const n=o.target.closest("[data-action]");if(n){const r=n.dataset.action;if(r==="close"){e.remove(),k=null;return}if(r==="import"){ee();return}if(r==="open-app"){te();return}if(r==="retry"){h=!1,d=null,m(),U().then(async l=>I((await S()).text,l));return}if(r==="test-nano"){re();return}return}a||(w=!w,m())})}function O(){if(document.getElementById("artemis-nano-bridge"))return;const e=document.createElement("script");e.id="artemis-nano-bridge",e.src=chrome.runtime.getURL("nano-inject.js"),document.documentElement.appendChild(e),e.addEventListener("load",()=>e.remove())}async function Z(e){if(document.getElementById("artemis-overlay"))return;O();const t=document.createElement("style");t.textContent=X,document.head.appendChild(t);const o=document.createElement("div");o.id="artemis-overlay",document.body.appendChild(o),k=o,W().then(r=>{o.style.bottom="auto",o.style.right="auto",o.style.left=r.x+"px",o.style.top=r.y+"px"}),w=!1,g=!!e.fingerprint,C=e.fallbackMode,d=null,h=!1,M=!1,A=!1,f=null,E=!1;const a=document.body.innerText,n=await S();x={title:n.title||N(a).title,company:N(a).company,salary:N(a).salary},m(),Q(o),g&&I(n.text,e),_||(_=!0,chrome.storage.onChanged.addListener(r=>{if(!k)return;const l=r[j];if(!l)return;const c=l.newValue||l.oldValue;if(!c)return;const u=g;g=!!c.fingerprint,C=c.fallbackMode,console.log("[Artemis] storage changed: hadFingerprint:",u,"hasFingerprint:",g,"matchScore:",d),g&&!u&&d===null?(console.log("[Artemis] storage changed: re-triggering computeMatch"),S().then(s=>I(s.text,c))):g!==u&&(g?(h=!1,console.log("[Artemis] storage changed: fingerprint appeared, re-triggering computeMatch"),S().then(s=>I(s.text,c))):m())}))}async function S(){var t;if(location.hostname.includes("linkedin.com")){document.querySelector(".jobs-unified-top-card__title, .job-details-jobs-unified-top-card__job-title")||await new Promise(p=>{let y=0;const v=6e3,T=setInterval(()=>{y+=500,(document.querySelector(".jobs-unified-top-card__title, .job-details-jobs-unified-top-card__job-title")||document.body.innerText.toLowerCase().includes("about the job")||y>=v)&&(clearInterval(T),p())},500)});let o=document.body.innerText;const a=["about the job","about this role","job description"],n=["job search faster with premium","about the company","show more","people also viewed"],r=o.split(`
`).map(p=>p.trim());let l=0,c=r.length;for(let p=0;p<r.length;p++){const y=r[p].toLowerCase();if(a.some(v=>y.startsWith(v))){l=p;break}}for(let p=l+1;p<r.length;p++){const y=r[p].toLowerCase();if(n.some(v=>y.startsWith(v))){c=p;break}}o=r.slice(l,c).join(`
`).trim();const u=document.querySelector(".jobs-unified-top-card__title, .job-details-jobs-unified-top-card__job-title, h1"),s=((t=u==null?void 0:u.innerText)==null?void 0:t.trim())||document.title;return{title:s,text:`${s}

${o}`,url:location.href}}return{title:document.title,text:document.body.innerText,url:location.href}}async function ee(){if(!M){M=!0,m();try{const e=await S();chrome.runtime.sendMessage({type:"ARTEMIS_IMPORT_JOB",payload:e}).catch(()=>{}),A=!0,M=!1,m()}catch(e){console.error("[Artemis] Import failed:",e),M=!1,m()}}}async function te(){chrome.runtime.sendMessage({type:"ARTEMIS_OPEN_APP"}).catch(()=>{})}async function I(e,t){console.log("[Artemis] computeMatch start, hasFingerprint:",!!t.fingerprint,"fallbackMode:",t.fallbackMode,"text.length:",e.length),h=!1,d=null,f=null,m();try{console.log("[Artemis] computeMatch: calling ensureNano...");const o=await oe();if(console.log("[Artemis] computeMatch: ensureNano result:",o),o){f=null,m(),console.log("[Artemis] computeMatch: extracting title via Nano...");try{const n=String(await b("nano-title",{text:e},void 0,15e3));n&&n.length<200&&(x.title=n,m())}catch{}console.log("[Artemis] computeMatch: calling nano-score...");const a=String(await b("nano-score",{text:e,fp:t.fingerprint}));console.log("[Artemis] computeMatch: nano-score raw result:",JSON.stringify(a)),d=F(a),console.log("[Artemis] computeMatch: parsed score:",d)}else if(t.fallbackMode!=="basic"){console.log("[Artemis] computeMatch: Nano unavailable, trying remoteMatch with fallback:",t.fallbackMode);const a=await ae(e,t.fingerprint,t);console.log("[Artemis] computeMatch: remoteMatch raw result:",JSON.stringify(a)),d=F(a),console.log("[Artemis] computeMatch: parsed score:",d)}else console.log("[Artemis] computeMatch: Nano unavailable, fallbackMode is basic — no scoring")}catch(o){console.error("[Artemis] computeMatch: exception:",o),d=null}d===null&&g&&(console.log("[Artemis] computeMatch: score is null, marking scoringFailed"),h=!0),f=null,m(),console.log("[Artemis] computeMatch: done, matchScore:",d,"scoringFailed:",h)}async function oe(){console.log("[Artemis] ensureNano: checking nano bridge...");try{await b("nano-ping",void 0,void 0,3e3),console.log("[Artemis] ensureNano: bridge alive")}catch{console.log("[Artemis] ensureNano: bridge not responding, re-injecting..."),O(),await new Promise(e=>setTimeout(e,500));try{await b("nano-ping",void 0,void 0,3e3),console.log("[Artemis] ensureNano: bridge alive after re-inject")}catch{return console.log("[Artemis] ensureNano: bridge still dead after re-inject"),!1}}console.log("[Artemis] ensureNano: calling nano-ensure...");try{const e=await b("nano-ensure",void 0,t=>{console.log("[Artemis] ensureNano: progress:",t),f=t,m()},3e5);return console.log("[Artemis] ensureNano: nano-ensure result:",e),!!e}catch(e){return console.error("[Artemis] ensureNano: nano-ensure exception:",e),!1}}function b(e,t,o,a=12e4){return console.log("[Artemis] postMessageToNano: sending",e,"timeout:",a),new Promise((n,r)=>{const l=crypto.randomUUID(),c=s=>{var p;if(s.source===window&&((p=s.data)==null?void 0:p.source)==="artemis-nano"&&s.data.requestId===l){if(s.data.progress){console.log("[Artemis] postMessageToNano: progress for",e,":",s.data.progress),o==null||o(s.data.progress);return}window.removeEventListener("message",c),clearTimeout(u),s.data.error?(console.error("[Artemis] postMessageToNano: error for",e,":",s.data.error),r(new Error(s.data.error))):(console.log("[Artemis] postMessageToNano: result for",e,":",s.data.result),n(s.data.result))}};window.addEventListener("message",c);const u=setTimeout(()=>{console.error("[Artemis] postMessageToNano: TIMEOUT for",e,"after",a+"ms"),window.removeEventListener("message",c),r(new Error("Nano timeout"))},a);window.postMessage({source:"artemis-overlay",method:e,args:t,requestId:l},"*")})}async function re(){E=!0,f=null,m();try{await b("nano-ping",void 0,void 0,3e3)}catch{console.log("[Artemis] Nano bridge not responding, re-injecting..."),O(),await new Promise(e=>setTimeout(e,500));try{await b("nano-ping",void 0,void 0,3e3)}catch{f=i("overlay.bridgeNotLoaded"),E=!1,m();return}}try{const e=await b("nano-test",void 0,o=>{f=o,m()},12e4),t=typeof e=="string"?JSON.parse(e):e;f=t.ok?i("overlay.nanoAvailable"):"✗ "+(t.error||"unavailable")}catch{f=i("overlay.nanoErrorTimedOut")}E=!1,m()}async function ae(e,t,o){console.log("[Artemis] remoteMatch: fallback:",o.fallbackMode,"text.length:",e.length);const a=await chrome.runtime.sendMessage({type:"ARTEMIS_LLM_SCORE",payload:{fingerprint:t,jobText:e.slice(0,8e3),fallbackMode:o.fallbackMode}});return console.log("[Artemis] Remote match response:",a),(a==null?void 0:a.score)??""}function F(e){const t=e.match(/(\d+)/);if(!t)return null;const o=parseInt(t[1],10);return isNaN(o)?null:Math.max(0,Math.min(100,o))}async function z(){console.log("[Artemis] Overlay init on",location.hostname,"URL:",location.href),k&&(console.log("[Artemis] init: removing stale overlay"),k.remove(),k=null);const e=await U();if(console.log("[Artemis] init: config loaded:",JSON.stringify({...e,fingerprint:e.fingerprint?"(present, "+e.fingerprint.length+" chars)":void 0})),!e.enabled){console.log("[Artemis] Overlay disabled in config");return}if(!D(location.href,e.jobSites)){console.log("[Artemis] Not a known job site:",location.hostname);return}Z(e)}let P=!1;function R(){if(P)return;P=!0;let e=location.href,t=null;function o(){if(t)return;const r=location.href;if(r===e)return;const l=document.body.innerText;console.log("[Artemis] URL changed:",e,"->",r),e=r,t=setTimeout(async()=>{t=null;for(let c=0;c<25&&(await new Promise(u=>setTimeout(u,200)),document.body.innerText===l);c++);z()},500)}const a=history.pushState.bind(history);history.pushState=(r,l,c)=>{a(r,l,c),o()};const n=history.replaceState.bind(history);history.replaceState=(r,l,c)=>{n(r,l,c),o()},window.addEventListener("popstate",o),setInterval(o,1e3)}document.readyState==="loading"?document.addEventListener("DOMContentLoaded",()=>{z(),R()}):(z(),R());
